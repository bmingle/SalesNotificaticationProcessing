/**
 * 
 */
package com.technical.test.MessageProcessing.Interface;

import java.util.Queue;

/**
 * @author Bhagyashree
 *
 */
public interface MessageConsumer {

	void consumeMessage(Queue<String> messageQ);

}
